/// <reference types="vite/client" />

interface Window {
  loadPyodide: any;
  tailwind: any;
}
